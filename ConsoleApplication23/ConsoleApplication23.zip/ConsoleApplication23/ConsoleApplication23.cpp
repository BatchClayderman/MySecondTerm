﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Student
{
	char name[10];
	int num;
	char sex[5];
	int grade0;
	int grade1;
	int grade2;
	int grade3;
	Student* next;
};

Student* Head = NULL;
Student* End = NULL;

void CreatList()
{
	Head = (struct Student*)malloc(sizeof(struct Student));
	Head->next = NULL;
	Student* End = Head;
}

void AddStudent()//初始化学生成绩信息
{
	struct Student* StuNew = (struct Student*)malloc(sizeof(struct Student));
	if (StuNew == NULL)
	{
		printf("\n空间分配失败\n\n");
		exit(-1);
	}
	StuNew->next = NULL;
	printf("\n要添加的学生的信息如下:\n");
	printf("\n请输入学生学号: ");
	scanf_s("%d", &(StuNew->num));

	//检查学号是否重复
	if (Head->next)
	{
		Student* temp = Head->next;
		while (temp != NULL)
		{
			if (temp->num == StuNew->num)
			{
				printf("\n学号重复，请重新输入\n");
				printf("\n请重新输入第%d个学生学号: ");
				scanf_s("%ld", &StuNew->num);
				temp = Head->next;//重新遍历比较
				continue;
			}
			else
				temp = temp->next;
		}
	}
	printf("请输入学生姓名: ");
	rewind(stdin);
	while (scanf_s("%s", &(StuNew->name), sizeof(StuNew->name)) != 1)
		rewind(stdin);
	printf("请输入学生性别: ");
	while (scanf_s("%s", &(StuNew->sex), sizeof(StuNew->sex)) != 1)
		rewind(stdin);
	printf("请输入学生数学分析成绩: ");
	while (scanf_s("%d", &(StuNew->grade0)) != 1)
		rewind(stdin);
	printf("请输入学生数学基础成绩: ");
	while (scanf_s("%d", &(StuNew->grade1)) != 1)
		rewind(stdin);
	printf("请输入学生英语成绩: ");
	while (scanf_s("%d", &(StuNew->grade2)) != 1)
		rewind(stdin);
	printf("请输入学生体育成绩: ");
	while (scanf_s("%d", &(StuNew->grade3)) != 1)
		rewind(stdin);
	Head->next = StuNew;
	StuNew->next = End;
	printf("\n\n学生信息全部添加完成\n");
}

void DelStu()//通过前驱结点删除学生成绩信息
{
	int num;
	printf("\n请输入您要删除的学生的学号：");
	scanf_s("%d", &num);
	Student* pre = Head;//表中没有数据时，pre为空； 
	while (true)
	{
		if (pre->next && (pre->next->num == num))
		{
			Student* q = pre->next;
			pre->next = pre->next->next;//pre->next = NULL;
			printf("\n\n 删除操作成功\n");
			printf("\n已删除的学生信息如下\n\n");
			printf("学生\t姓名\t%s\t学号\t%d\t性别\t%s\t\n", q->name, q->num, q->sex);
			free(q);
			return;
		}
		else
		{
			if (pre->next != NULL)
				pre = pre->next;
			else
			{
				printf("\n表为空，信息删除失败\n");
				return;
			}
		}
	}
}

void AltStu()
{
	int num; int n;
	printf("请输入您想修改的学生的学号：\n");
	scanf_s("%d", &num);
	Student* q = Head->next;
	while (q && q->num == num)
	{
		q = q->next;
	}
	if (q)
	{
		printf("请选择您需要修改的选项：0.学号	1.姓名	2.性别（一次只能选择一项）\n");
		scanf_s("%d", &n);
		switch (n)
		{
		case'0': {printf("请输入更改后的学号："); scanf_s("%d", &q->num); }
		case'1': {printf("请输入更改后的姓名："); scanf_s("%s", q->name); }
		case'2': {printf("请输入更改后的性别："); scanf_s("%s", q->sex); }
		}
		printf("\n");
	}
	else printf("\n该学号不存在，修改失败\n");
}

void SeekStudent()
{
	int num;
	printf("\n请输入您要查找学生的学号：");
	scanf_s("%d", &num);
	Student* q = Head->next;
	while (q && (q->num != num))
		q = q->next;
	if (q)
	{
		printf("\n该学生信息如下：\n");
		printf("学号\t%d\t姓名\t%s\t性别\t%s\n", q->num, q->name, q->sex);
		printf("数学分析\t%d\t数学基础\t%d\t英语\t%d\t体育\t%d\n", q->grade0, q->grade1, q->grade2, q->grade3);
	}
	else
		printf("\n未查询到该学生信息\n");
	system("pause");
	return;
}

void Insert()
{
	struct Student* _StuNew = (struct Student*)malloc(sizeof(struct Student));
	if (_StuNew == NULL)
	{
		printf("\n空间分配失败\n\n");
		exit(-1);
	}
	_StuNew->next = NULL;
	printf("\n请输入学生学号: ");
	rewind(stdin);
	while (scanf_s("%d", &(_StuNew->num)) != 1)
		rewind(stdin);

	//检查学号是否重复
	if (Head->next)
	{
		Student* temp = Head->next;
		while (temp != NULL)
		{
			if (temp->num == _StuNew->num)
			{
				printf("\n学号重复，请重新输入\n");
				printf("\n请重新输入学生学号: ");
				scanf_s("%ld", &_StuNew->num);
				temp = Head->next;//重新遍历比较
				continue;
			}
			else
				temp = temp->next;
		}
	}
	printf("请输入学生姓名: ");
	rewind(stdin);
	while (scanf_s("%s", &(_StuNew->name), sizeof(_StuNew->name)) != 1)
		rewind(stdin);
	printf("请输入学生性别: ");
	while (scanf_s("%s", &(_StuNew->sex), sizeof(_StuNew->sex)) != 1)
		rewind(stdin);
	printf("请输入学生数学分析成绩: ");
	while (scanf_s("%d", &(_StuNew->grade0)) != 1)
		rewind(stdin);
	printf("请输入学生数学基础成绩: ");
	while (scanf_s("%d", &(_StuNew->grade1)) != 1)
		rewind(stdin);
	printf("请输入学生英语成绩: ");
	while (scanf_s("%d", &(_StuNew->grade2)) != 1)
		rewind(stdin);
	printf("请输入学生体育成绩: ");
	while (scanf_s("%d", &(_StuNew->grade3)) != 1)
		rewind(stdin);
	_StuNew->next = Head->next;
	Head->next = _StuNew;
	printf("\n\n学生信息插入完成\n");
}

void Delete()
{
	Student* p = Head;
	if (p->next == End)
	{
		printf("没有学生");
		return;
	}
	int num;
	printf("\n请输入您要删除的学生的学号：");
	rewind(stdin);
	while (scanf_s("%d", &num) != 1)
		rewind(stdin);
	while (p)
	{
		if (p->next->num == num)
		{
			p->next = p->next->next;
			return;
		}
		else
		{
			printf("学生不存在");
			return;
		}
		p = p->next;
	}
}

void Alter()
{
	int num, n;
	printf("请输入您想修改的学生的学号：\n");
	scanf_s("%d", &num);
	Student* q = Head->next;
	while (q && q->num == num)
	{
		q = q->next;
	}
	if (q)
	{
		printf("请选择您需要修改的科目：0.数学分析	1.数学基础	2.英语	3.体育（一次只能选择一项）\n");
		rewind(stdin);
		while (scanf_s("%d", &n) != 1)
			rewind(stdin);
		printf("请输入更改后的成绩：");
		rewind(stdin);
		switch (n)
		{
		case'0': 
			scanf_s("%d", (q->grade0)); 
			break;
		case'1':
			scanf_s("%d", (q->grade1));
			break;
		case'2': 
			scanf_s("%d", (q->grade2));
			break;
		case'3':
			scanf_s("%d", (q->grade3));
			break;
		}
		printf("\n");
	}
	else
		printf("\n该学号不存在，修改失败\n");
}

void FreeScore()
{
	int num, n;
	printf("请输入您想修改的学生的学号：\n");
	scanf_s("%d", &num);
	Student* q = Head->next;
	while (q && q->num == num)
	{
		q = q->next;
	}
	if (q)
	{
		printf("请选择您需要修改的科目：0.数学分析	1.数学基础	2.英语	3.体育（一次只能选择一项）\n");
		rewind(stdin);
		while (scanf_s("%d", &n) != 1)
			rewind(stdin);
		switch (n)
		{
		case '0':
			q->grade0 = 0;
			break;
		case '1':
			q->grade1 = 0;
			break;
		case '2':
			q->grade2 = 0;
			break;
		case '3':
			q->grade3 = 0;
			break;
		default:
			return;
		}
		printf("\n");
	}
	else
		printf("\n该学号不存在，修改失败\n");
}

void z()//关键字查找学生信息
{
	char keyword = '\0';
	printf("请输入关键字：\n");
	rewind(stdin);
	scanf_s("%c", &keyword, sizeof(keyword));
	rewind(stdin);
	Student* q = Head->next;
	while (q)
	{
		for (int i = 0; i < strlen(q->name); i++)
			if (q->name[i] == keyword)
			{
				printf("%s", q->name);
				break;
			}
		q = q->next;
	}
	printf("\n查找完毕，请按任意键返回。");
	system("pause>nul");
}

void print()
{
	Student* q = Head->next;
	printf("head->");
	if (q)
		while (q)
		{
			printf("%d->", q->num);
			q = q->next;
		}
	printf("end\n");
	return;
}

int main()
{
	system("chcp 936&title 学生成绩管理系统&cls");
	CreatList();
	while (true)
	{
		system("cls");
		printf("当前所有学生ID：");
		print();
		printf("/******学生成绩管理系统******/\n0.初始化学生信息\n1.删除学生信息\n2.修改学生信息\n3.查询学生成绩\n4.插入学生成绩\n5.删除学生成绩\n6.修改学生成绩\n7.关键字查询\n\n");
		rewind(stdin);
		int a = getchar();
		rewind(stdin);
		switch (a)
		{
		case'0':
			AddStudent();
			break;
		case'1':
			Delete();
			break;
		case'2':
			AltStu();
			break;
		case'3':
			SeekStudent();
			break;
		case'4':
			Insert();
			break;
		case'5':
			FreeScore();
			break;
		case'6':
			Alter();
			break;
		case'7':
			z();
			break;
		default:
			return 0;
		}
	}
	return -2;
}